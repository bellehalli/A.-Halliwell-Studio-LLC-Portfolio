# Set & Stare — Setup Guide

This guide is included with your lash and brow studio website template. You do not need a special editor: use any plain-text editor for the source files and a browser to preview the site.

## 1. Unzip and preview

1. Extract the complete ZIP folder. Keep the folder structure intact, including `assets/`.
2. Open `index.html` in a modern browser to see the starter site.
3. Keep a backup copy before editing.

## 2. Replace the business details

1. Open `site-data.js` and replace every sample business name, tagline, phone, email, address, social profile, hours, and external booking or inquiry URL with your own verified details.
2. Search the HTML files for sample brand names and replace them. Update `index.html`, `about.html`, `services.html`, `gallery.html`, `policies.html`, and `book.html` wherever sample text appears.
3. Replace the example service names, descriptions, prices, durations, policies, and calls to action. The sample content is illustrative; it is not your business information.
4. Edit the service page and the featured service cards on the home page so they agree.

## 3. Make the visuals yours

1. Replace `assets/studio-hero.webp` and the gallery images with photos you own or have permission to use.
2. Keep replacement filenames the same, or update the matching image paths in the HTML.
3. Open `styles.css` and adjust the color variables near the beginning of the file. Check text contrast after changing colors.
4. Review image crops and headings at phone width as well as desktop width.

## 4. Set & Stare industry checklist

Replace sample services with your actual lash sets, fills, lifts, brow services, timing, aftercare, and suitability notes. Use your own work photos and ensure your scheduler explains patch tests or consultation requirements where applicable.

## 5. Check every path before launch

- Tap every navigation item and primary button on desktop and on a phone.
- Confirm the booking, ticket, guest-list, inquiry, phone, email, and social links open the right destination.
- Check spelling, prices, dates, business hours, address, mobile layout, image loading, and page titles.
- Remove all placeholder contact details, claims, sample prices, and fictional policies.

## 6. Publish

Upload the **entire extracted folder** to a static website host and connect your domain. Preserve the relative file paths so the CSS, JavaScript, and images load. Enable HTTPS, then visit the published pages on a phone and test the links again.

The template is a coded HTML/CSS/JavaScript site. Domain registration, hosting, scheduling, ticket sales, dispatch software, payment processing, custom copywriting, and ongoing maintenance are separate. The template links to external services; it does not itself take appointments, sell tickets, process payments, diagnose equipment, or create availability.

## License reminder

Your purchase covers one business and one website. You may customize and publish it for that business. You may not resell, redistribute, share, or repackage the source files, or use them to create a website for another business. A. Halliwell Studio retains the original template and its intellectual property.
