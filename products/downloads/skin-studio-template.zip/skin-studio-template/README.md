# Stillwater Skin Studio Website Template

A responsive six-page HTML, CSS, and JavaScript website starter for an independent esthetician and skincare studio.

## Pages included

- `index.html` — studio introduction, featured services, imagery, and booking calls to action
- `services.html` — niche-specific service menu and example starting prices
- `about.html` — studio story and approach
- `gallery.html` — portfolio gallery layout
- `policies.html` — appointment policies and preparation notes
- `book.html` — booking link, contact details, hours, and location

## Make it yours

For the complete walkthrough, open the included `SETUP.md`. It is tailored to Estheticians and skincare studios and covers editing, preview, launch checks, and publishing.

1. Open `site-data.js` in a text editor.
2. Replace the sample studio name, address, phone, social link, and booking URL.
3. Update service names, descriptions, prices, and times in `services.html` and the featured cards in `index.html`. Prices in the sample are fictional placeholders.
4. Replace `assets/studio-hero.webp` and the gallery placeholders with photographs you own or have permission to use.
5. Open `index.html` in a browser to preview the site.
6. Upload the whole folder to a static web host connected to your domain. Domain registration, hosting, and appointment-booking software are separate.

The template includes responsive navigation and booking buttons that link to your existing scheduling page. It does not create appointment availability, take deposits, or process payments. This is a coded HTML/CSS/JavaScript download, not a Squarespace, Wix, Canva, or Shopify theme.

## Purchase terms

The $149 DIY purchase is for one business and one website. You may edit and use the template for your own business. You may not resell, redistribute, share, or repackage the source files, or use them to build a website for another business. For the $1,250 implementation package, AHS may use the template to create the one website purchased by that business. AHS retains the original template and underlying intellectual property. Digital template sales are delivered after payment is confirmed.

## Sample content

The sample business, contact information, service menu, descriptions, prices, and times are fictional placeholders. Replace them before publication. The included sample photograph is for template demonstration; replace it with imagery that represents your own business before launch.
