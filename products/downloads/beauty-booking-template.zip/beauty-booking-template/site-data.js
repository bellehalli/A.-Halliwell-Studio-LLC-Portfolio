/* Replace the sample studio details and booking destination before publishing. */
window.STUDIO_SITE = {
  name: "Muse Hair Studio",
  tagline: "Hair with intention.",
  bookingUrl: "https://your-booking-link.example",
  instagramUrl: "https://instagram.com/yourstudio",
  phone: "(313) 555-0148",
  email: "hello@yourstudio.com",
  address: "Detroit, Michigan",
  hours: "By appointment",
};
