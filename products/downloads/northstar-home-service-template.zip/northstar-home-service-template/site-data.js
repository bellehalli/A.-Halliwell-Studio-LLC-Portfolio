/* Replace the sample studio details and service request destination before publishing. */
window.STUDIO_SITE = {
  name: "Northstar Heating & Home",
  tagline: "Clear help for your home.",
  bookingUrl: "https://your-service-request-link.example",
  instagramUrl: "https://instagram.com/yourstudio",
  phone: "(313) 555-0148",
  email: "hello@yourstudio.com",
  address: "Detroit, Michigan",
  hours: "During service hours",
};
