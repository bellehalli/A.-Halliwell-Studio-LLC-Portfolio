# Northstar Heating & Home Services Website Template

A responsive six-page HTML, CSS, and JavaScript starter for an HVAC or home-service business. Its service-routing language helps homeowners choose a next step for urgent concerns, repairs, maintenance, and replacement inquiries.

## Included pages

- `index.html` — business introduction, featured home-service options, and service request links
- `services.html` — service options and request paths
- `about.html` — team story and company approach
- `gallery.html` — project and team photography layout
- `policies.html` — service area, dispatch, and visit policy placeholders
- `book.html` — service request link, phone, hours, and location

## Setup

1. Edit `site-data.js` with the verified business name, address, phone, email, hours, and service request URL.
2. Replace all sample service details, areas served, license and insurance information, arrival expectations, warranty terms, emergency availability, and financing details with verified information.
3. Replace the hero photograph and gallery placeholders with imagery you own or have permission to use.
4. Preview `index.html` in a browser, then upload the full folder to a static host connected to your domain. Hosting, domain registration, and dispatch or service request software are separate.

This coded HTML/CSS/JavaScript template links to your external contact or dispatch system. It does not diagnose equipment, book a technician automatically, or produce a quote. It is not a Squarespace, Wix, Canva, or Shopify theme.

## License and sample content

The $149 DIY purchase covers one business and one website. You may edit and use the files for your own business; reselling, redistributing, or using the source to build sites for other businesses is not permitted. The $1,250 implementation option covers one customized website. AHS retains the original template and its intellectual property.

Northstar Heating & Home and the sample contact information, service areas, pricing, licenses, and claims are fictional. Replace them with verified business details before publishing.
