/* Replace the sample studio details and ticketing or guest-list destination before publishing. */
window.STUDIO_SITE = {
  name: "Vanta Social",
  tagline: "Your night, in a new light.",
  bookingUrl: "https://your-ticketing-or-guest-list-link.example",
  instagramUrl: "https://instagram.com/yourstudio",
  phone: "(313) 555-0148",
  email: "hello@yourstudio.com",
  address: "Detroit, Michigan",
  hours: "Event nights",
};
