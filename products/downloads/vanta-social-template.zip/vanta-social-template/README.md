# Vanta Social Nightlife Website Template

A responsive six-page HTML, CSS, and JavaScript starter for an independent nightlife venue or events brand.

## Included pages

- `index.html` — event introduction, featured nights, and ticket or guest-list calls to action
- `services.html` — event calendar, guest-list details, VIP inquiries, and arrival information
- `about.html` — venue story and team introduction
- `gallery.html` — event photography layout
- `policies.html` — entry, age, cancellation, and venue information placeholders
- `book.html` — ticketing or guest-list link, venue contact, hours, and location

## Setup

1. Edit `site-data.js` with the real venue name, address, phone, social link, and ticketing or guest-list URL.
2. Replace sample event names, dates, age limits, entry rules, ticket prices, table minimums, and venue details with current verified information.
3. Replace the sample hero photograph and gallery placeholders with imagery you own or have permission to use.
4. Open `index.html` to preview, then upload the full folder to a static host connected to your domain. Hosting, domain registration, and ticketing, guest-list, or reservation software are separate.

This coded HTML/CSS/JavaScript template links to an external platform. It does not sell tickets or process payments. It is not a Squarespace, Wix, Canva, or Shopify theme.

## License and sample content

The $999 DIY purchase covers one business and one website. You may edit and use the files for your own venue or events brand; reselling, redistributing, or using the source to build sites for other businesses is not permitted. The $5,000+ implementation option covers one customized website. AHS retains the original template and its intellectual property.

Vanta Social, event names, dates, venue details, contact information, prices, and all other sample content are fictional. Replace them before publishing.
